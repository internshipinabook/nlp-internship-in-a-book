# The Computer Vision Internship
**InternshipInABook™ · Book 3 of 9**

## Get the Full Book
👉 **[SELAR_LINK_PLACEHOLDER]**

## Quick Start
**Local:** `pip install -r requirements.txt` then `jupyter notebook`
**Colab:** Click any Open in Colab badge in a STARTER notebook

## Dataset
Run `python generate_images.py` in `datasets/` folder.

## Repository
`git clone https://github.com/internshipinabook/cv-internship-in-a-book.git`

© Sakinat Folorunso 2026
